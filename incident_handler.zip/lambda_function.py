import json
import boto3
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize SNS client
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    # Log the event details
    logger.info(f"Received event: {json.dumps(event)}")

    # Example: Extract information from the event (could be GuardDuty or CloudWatch alarm)
    if 'detail' in event:
        incident_details = event['detail']
    else:
        incident_details = "No incident details provided."

    # Construct an incident report message
    message = f"Incident detected: {incident_details}"

    # Publish a notification to the SNS topic
    response = sns_client.publish(
        TopicArn = os.environ['SNS_TOPIC'],  # SNS Topic ARN is passed via environment variables
        Message = message,
        Subject = "AWS Incident Response"
    )

    # Log SNS response
    logger.info(f"Notification sent, response: {response}")

    return {
        'statusCode': 200,
        'body': json.dumps('Incident handled successfully!')
    }
